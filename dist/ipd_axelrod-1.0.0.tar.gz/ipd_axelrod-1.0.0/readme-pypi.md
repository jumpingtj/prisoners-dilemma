# IDP - the tool for study of the Iterated Prisoners' Dilemma

Currently, this provides no exports, and must be run via the command line:
`python3 -m IDP`
This produces a GUI window for running simulations.
