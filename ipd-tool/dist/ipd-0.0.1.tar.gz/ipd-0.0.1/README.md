# IDP - the tool for study of the Iterated Prisoners Dilemma

This currently provides no exports and is just a test.